/*
 * temperature.c
 *
 *  Created on: Apr 9, 2019
 *      Author: harsi
 */
#include <include/temperature.h>

status_enum ultrasonic_sensor_read(float *distance_value)
{
    float distance = 0;
    int ultrasonic_count = 0;
    uint32_t distancecounter = 0;
    /*trigger*/
    GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6, ~(GPIO_PIN_6));
    SysCtlDelay(1250); //Delay by 10us

    GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6, GPIO_PIN_6);
    SysCtlDelay(1250); //Delay by 10us

    GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_6, ~(GPIO_PIN_6));

    /*read echo*/
    while(GPIOPinRead(GPIO_PORTL_BASE, GPIO_PIN_3) == 0)
    {
        ultrasonic_count++;
        if(ultrasonic_count > 500)
        {
            *distance_value = -1.0;
            return SUCCESS;
        }
    }
    while ((GPIOPinRead(GPIO_PORTL_BASE, GPIO_PIN_3) != 0) & (distancecounter<MAX_TIME))
    {
       distancecounter++;
       SysCtlDelay(120); //Delay by 1us

    }

    /*convert*/
    distance = ((float)distancecounter/(float)58.2);
    distance = distance *6;
    *distance_value = distance;
    return SUCCESS;
}
