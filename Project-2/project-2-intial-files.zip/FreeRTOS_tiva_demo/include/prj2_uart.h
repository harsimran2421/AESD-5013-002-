/*
 * prj2_uart.h
 *
 *  Created on: Apr 21, 2019
 *      Author: harsi
 */

#ifndef INCLUDE_PRJ2_UART_H_
#define INCLUDE_PRJ2_UART_H_

/*user defined libraries*/
#include <include/FreeRTOSConfig.h>
#include <include/harry_i2c.h>
#include <include/main.h>
#include <include/threads.h>
#include <include/prj2_gpio.h>

/*standard libraries*/
#include <stdint.h>
#include <stdbool.h>
#include "drivers/pinout.h"
#include "utils/uartstdio.h"


// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/timer.h"
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/gpio.h"
#include "driverlib/uart.h"


void configure_UART(void);


#endif /* INCLUDE_PRJ2_UART_H_ */
