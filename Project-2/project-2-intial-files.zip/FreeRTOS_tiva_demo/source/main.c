/*
 * Refernce:
 * FreeRTOS 8.2 Tiva Demo
 *
 * main.c
 *
 * Andy Kobyljanec
 *
 * This is a simple demonstration project of FreeRTOS 8.2 on the Tiva Launchpad
 * EK-TM4C1294XL.  TivaWare driverlib sourcecode is included.
 */

/*user defined libraries*/
#include <include/FreeRTOSConfig.h>
#include <include/harry_i2c.h>
#include <include/main.h>
#include <include/threads.h>
#include <include/prj2_gpio.h>
#include <include/prj2_uart.h>
#include <include/prj2_alcohol.h>

/*standard libraries*/
#include <stdint.h>
#include <stdbool.h>
#include "drivers/pinout.h"
#include "utils/uartstdio.h"


// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/timer.h"
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/gpio.h"
#include "driverlib/uart.h"



// FreeRTOS includes
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "timers.h"

// Main function
int main(void)
{
    led_signal = xSemaphoreCreateBinary();
    temp_signal = xSemaphoreCreateBinary();
    alcohol_signal = xSemaphoreCreateBinary();
    log_m = xSemaphoreCreateMutex();
    uint32_t output_clock_rate_hz;
    output_clock_rate_hz = ROM_SysCtlClockFreqSet(
                               (SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
                               SYSTEM_CLOCK);
    ASSERT(output_clock_rate_hz == SYSTEM_CLOCK);
    //ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);    //Enable GPIO

    PinoutSet(false, false);
    queue_create();
    configure_UART();

     GPIO_Init();
    //I2C_Init();

//     UARTprintf("Clean Air Ratio in Main: %s\n\n\n\n", cac);

     /*initialise and caliberate alcohol sensor*/
     SysCtlDelay(120000); //Delay by 10us

    TIMER_Init();

//    xTaskCreate(LEDTask, (const portCHAR *)"LED",  configMINIMAL_STACK_SIZE, NULL, 1, NULL);

//    xTaskCreate(LoggerTask, (const portCHAR *)"Serial",  configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    xTaskCreate(alcohol_sensor, (const portCHAR *)"alcohol_task",  configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    xTaskCreate(ultrasonic_sensor, (const portCHAR *)"Temperature",  configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    vTaskStartScheduler();
    return 0;
}

void TIMER_Init()
{
       TimerHandle_t myTimer = NULL;
       myTimer = xTimerCreate(
               "Timer1",
               pdMS_TO_TICKS(100),
               pdTRUE,
               (void *) pvTimerGetTimerID(myTimer),
               timerTask
             );
      xTimerStart(myTimer, 0);
}


/*  ASSERT() Error function
 *
 *  failed ASSERTS() from driverlib/debug.h are executed in this function
 */
void __error__(char *pcFilename, uint32_t ui32Line)
{
    // Place a breakpoint here to capture errors until logging routine is finished
    while (1)
    {
    }
}


