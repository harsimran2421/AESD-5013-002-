/*
 * threads.c
 *
 *  Created on: Apr 9, 2019
 *      Author: harsi
 *      reference: https://github.com/akobyl/TM4C129_FreeRTOS_Demo
 *      reference
 */
#include <include/FreeRTOSConfig.h>
#include <include/main.h>
#include <include/temperature.h>
#include <include/threads.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "drivers/pinout.h"
#include "utils/uartstdio.h"


// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/timer.h"
#include "driverlib/interrupt.h"

// FreeRTOS includes
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

//QueueHandle_t queue_logger;
int queue_create(){
    queue_logger = xQueueCreate( 10, sizeof(msg_struct) );
    if( queue_logger == NULL )
       {
           return 0;
       }
    return 1;
}


// Flash the LEDs on the launchpad
void LEDTask(void *pvParameters)
{
    msg_struct msg;
    uint32_t run_count;
    while(1)
    {
        vTaskDelay(1000);
        if (xSemaphoreTake(led_signal, portMAX_DELAY) == pdTRUE)
         {
             LEDWrite(0x02, 0x02);
             LEDWrite(0x01, 0x01);
             vTaskDelay(pdMS_TO_TICKS(2));
             LEDWrite(0x02, 0x00);
             LEDWrite(0x01, 0x00);
             memset(msg.ip_str,'\0',sizeof(msg.ip_str));
             strcpy(msg.ip_str, "LED!!!!");
             msg.sensor_value = run_count++;
             msg.timestamp = xTaskGetTickCount();
             msg.thread_id = 2;

             if (xSemaphoreTake( log_m, ( TickType_t )20 ) == pdTRUE)

             {
                 xQueueSend(queue_logger, (void * ) &msg,
                            (TickType_t )1);
                 xSemaphoreGive(log_m);
             }

             vTaskDelay(pdMS_TO_TICKS(2));
         }
    }
}


// Write text over the Stellaris debug interface UART port
void LoggerTask(void *pvParameters)
{
//    msg_struct msg;
//    memset(msg.ip_str,'\0',sizeof(msg.ip_str));
//    while(1)
//    {
//        {
//            if (xQueueReceive(queue_logger, &(msg),(TickType_t ) 1) == pdTRUE)
//            {
//                if(msg.thread_id == 1)
//                {
//                    UARTprintf("\n\n\rTimestamp: %umsec\nAuthor: Harry\nALERT TASK:%s\n\r ",msg.timestamp,msg.ip_str);
//                }
//                else if(msg.thread_id == 3)
//                {
//                    UARTprintf("\n\n\rTimestamp:%u msec\n%s\nAuthor: Harry\nSensor value = %u Celsius\n\r ",msg.timestamp,msg.ip_str,
//                            (uint32_t) msg.sensor_value);
//                }
//                else if(msg.thread_id == 2)
//                {
//                    UARTprintf("\n\n\rTimestamp:%u msec\n%s\nAuthor: Harry\nCount = %u \n\r ",msg.timestamp,msg.ip_str,(uint32_t) msg.sensor_value);
//                }
//             }
//         }
//    }
}

void ultrasonic_sensor(void *pvParameters)
{
    msg_struct msg;
    float sensor_value;
    while(1)
    {
        if (xSemaphoreTake(temp_signal,portMAX_DELAY) == pdTRUE)
        {
            ultrasonic_sensor_read(&sensor_value);
            memset(msg.ip_str,'\0',sizeof(msg.ip_str));
            msg.sensor_value = sensor_value;
            msg.thread_id = 3;
            strcpy(msg.ip_str, "Ultrasonic Task");
            msg.timestamp = xTaskGetTickCount();
            UARTprintf("\n\n\rTimestamp:%u msec\n%s\nAuthor: Harry\nCount = %u \n\r ",msg.timestamp,msg.ip_str,(uint32_t) msg.sensor_value);
//            if (xSemaphoreTake( log_m, ( TickType_t )20 ) == pdTRUE)
//                ;
//            {
//                xQueueSend(queue_logger, (void * ) &msg, (TickType_t )1);
//                xSemaphoreGive(log_m);
//            }
       }
    }
}

void alcohol_sensor(void *pvParameters)
{
    cleangasconstant = alcohol_sensor_config();
    char cac[10];
    //cleangasconstant =2;
    sprintf(cac, "%f", cleangasconstant);
//    msg_struct msg;
//    float sensor_value;
    uint32_t alcraw[1];
    float alcvoltvalue = 0.0;
    float alcgasvalue = 0.0;
    float alcratio = 0.0;
    char printalc[10];

    while(1)
    {
        if (xSemaphoreTake(alcohol_signal,portMAX_DELAY) == pdTRUE)
        {
            /*Trigger ADC conversion*/
            ADCProcessorTrigger(ADC0_BASE, 3);

            /*Wait for conversion to complete*/
            while (!ADCIntStatus(ADC0_BASE, 3, false))
                ;

            /*Clear ADC interrupt flag*/
            ADCIntClear(ADC0_BASE, 3);

            /*Read ADC value*/
            ADCSequenceDataGet(ADC0_BASE, 3, alcraw);

            /*convert*/
            alcvoltvalue = (float) alcraw[0] / 1024.0 * 5.0;
            alcgasvalue = (5.0 - alcvoltvalue) / alcvoltvalue;
            alcratio = alcgasvalue / cleangasconstant;

            /*print the alcohol content*/
            memset(printalc, 0, sizeof(printalc));
            sprintf(printalc, "%f", alcratio);
            /*
             * 280 - sober
             * 280-350 - 1 beer
             * 350- 450 - few beers
             * 450 above - get outa the fucking car
             */
            UARTprintf("Alcohol Content = %s\n", printalc);
//            memset(msg.ip_str,'\0',sizeof(msg.ip_str));
//            msg.sensor_value = sensor_value;
//            msg.thread_id = 3;
//            strcpy(msg.ip_str, "Ultrasonic Task");
//            msg.timestamp = xTaskGetTickCount();
//            UARTprintf("\n\n\rTimestamp:%u msec\n%s\nAuthor: Harry\nCount = %u \n\r ",msg.timestamp,msg.ip_str,(uint32_t) msg.sensor_value);
       }
    }
}

void timerTask(TimerHandle_t mytimer)
{
    static int run_count;
    run_count++;
    if(run_count%10 == 0)
    {
        //xSemaphoreGive( temp_signal);
        xSemaphoreGive( alcohol_signal);
    }
}

