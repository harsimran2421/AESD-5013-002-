/*
 * prj2_alcohol.c
 *
 *  Created on: Apr 23, 2019
 *      Author: harsi
 */




#include <include/prj2_alcohol.h>

void ADC_Init(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);

    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_ADC0));

    ADCSequenceConfigure(ADC0_BASE, 3, ADC_TRIGGER_PROCESSOR, 0);

    ADCSequenceStepConfigure(ADC0_BASE,3,0,ADC_CTL_CH0|ADC_CTL_IE|ADC_CTL_END);

    ADCSequenceEnable(ADC0_BASE, 3);

    ADCIntClear(ADC0_BASE, 3);
}


float alcohol_sensor_config(void)
{
    ADC_Init();
    float alsvolt = 0.0;
    float alsair = 0.0;
    float ratio = 0.0;
    //char cratio[10];
    uint32_t alsvalue[1] = {0.0};
    float cumulativeval = 0.0;
    int i =0;
    for(i =0; i<100; i++)
    {
        /*Trigger ADC conversion*/
        ADCProcessorTrigger(ADC0_BASE, 3);

        /*Wait for conversion to complete*/
        while(!ADCIntStatus(ADC0_BASE, 3, false));

        /*Clear ADC interrupt flag*/
        ADCIntClear(ADC0_BASE, 3);

        /*Read ADC value*/
        ADCSequenceDataGet(ADC0_BASE, 3, alsvalue);

        cumulativeval += (float)alsvalue[0];
        memset(alsvalue, 0, sizeof(alsvalue));

     }
    cumulativeval = cumulativeval/100.0;
    alsvolt = (cumulativeval/1024)*5.0;
    alsair = (5.0 - alsvolt)/alsvolt;
    ratio = alsair/60.0;
    return ratio;
}
