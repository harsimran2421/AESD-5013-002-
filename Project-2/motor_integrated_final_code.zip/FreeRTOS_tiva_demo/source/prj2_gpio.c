/*
 * prj2_gpio.c
 *
 *  Created on: Apr 21, 2019
 *      Author: harsi
 */
#include <include/prj2_gpio.h>

void GPIO_Init()
{

    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOC))
    {
    }
//    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
//    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPION))
//        ;
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOL);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOL))
        ;

    /*The PC6 pin is set as trigger pin*/
    GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_6);
    GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_2);
    GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_1);
    GPIOPadConfigSet(GPIO_PORTL_BASE, GPIO_PIN_1,
                     GPIO_STRENGTH_12MA, GPIO_PIN_TYPE_STD);
    /*the PL3 is set as analog input for the ultrasonic sensor echo pin*/
    GPIOPinTypeGPIOInput(GPIO_PORTL_BASE, GPIO_PIN_3);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_3);



}


