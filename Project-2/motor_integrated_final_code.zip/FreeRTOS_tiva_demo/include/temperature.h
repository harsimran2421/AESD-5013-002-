/*
 * temperature.h
 *
 *  Created on: Apr 10, 2019
 *      Author: harsi
 */

#ifndef INCLUDE_TEMPERATURE_H_
#define INCLUDE_TEMPERATURE_H_
#include <include/harry_i2c.h>
#include <include/main.h>
#include <include/threads.h>
#include <include/prj2_gpio.h>
#include <include/harry_i2c.h>

#define MAX_TIME 7500

typedef enum{FAHRENHEIT, KELVIN, CELCIUS}conversion_enum;
status_enum ultrasonic_sensor_read(float *distance_value);

status_enum temp_main(conversion_enum request, double *temp_value);

#endif /* INCLUDE_TEMPERATURE_H_ */
