/*
 * prj2_alcohol.h
 *
 *  Created on: Apr 23, 2019
 *      Author: harsi
 */

#ifndef INCLUDE_PRJ2_ALCOHOL_H_
#define INCLUDE_PRJ2_ALCOHOL_H_

/*standard libraries*/
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

/*freertos includes*/
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "utils/uartstdio.h"

/*freertos driver libraries*/
#include "driverlib/i2c.h"
#include "driverlib/i2c.h"
#include "drivers/pinout.h"
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/gpio.h"
#include "driverlib/i2c.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "driverlib/adc.h"

void ADC_Init(void);

float alcohol_sensor_config(void);

#endif /* INCLUDE_PRJ2_ALCOHOL_H_ */
