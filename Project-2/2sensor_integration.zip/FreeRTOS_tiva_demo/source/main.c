/*
 * Refernce:
 * FreeRTOS 8.2 Tiva Demo
 *
 * main.c
 *
 * Harsimransingh Bindra & Yasir Aslam Shah
 *
 * This is a simple demonstration project of FreeRTOS 8.2 on the Tiva Launchpad
 * EK-TM4C1294XL.  TivaWare driverlib sourcecode is included.
 * Other references
 *      -https://github.com/LuisAfonso95/TM4C123-Launchpad-Examples/blob/master/srf04/main.c
 *      -Tiva adc.c code
 *      -https://github.com/harsimran2421/AESD-5013-002-/tree/master/Assignment-5
 */

/*user defined libraries*/
#include <include/FreeRTOSConfig.h>
#include <include/harry_i2c.h>
#include <include/main.h>
#include <include/threads.h>
#include <include/prj2_gpio.h>
#include <include/prj2_uart.h>
#include <include/prj2_alcohol.h>

/*standard libraries*/
#include <stdint.h>
#include <stdbool.h>
#include "drivers/pinout.h"
#include "utils/uartstdio.h"


// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/timer.h"
#include "inc/hw_memmap.h"
#include "driverlib/pin_map.h"
#include "driverlib/gpio.h"
#include "driverlib/uart.h"
#include "inc/hw_ints.h"
#include "driverlib/interrupt.h"




// FreeRTOS includes
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "timers.h"
#include <include/temperature.h>

// Main function
int main(void)
{
    /*initializing the semaphores*/
    led_signal = xSemaphoreCreateBinary();
    temp_signal = xSemaphoreCreateBinary();
    alcohol_signal = xSemaphoreCreateBinary();
    log_m = xSemaphoreCreateMutex();
    uint32_t output_clock_rate_hz;
    /*initializing the system clock*/
    output_clock_rate_hz = ROM_SysCtlClockFreqSet(
                               (SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
                               SYSTEM_CLOCK);
    ASSERT(output_clock_rate_hz == SYSTEM_CLOCK);

    PinoutSet(false, false);
    /*intialize the message queue*/
    queue_create();
    /*intialize the UART ports*/
    configure_UART();
    /*Intialize GPIO pins used*/
     GPIO_Init();

    SysCtlDelay(120000);
    /*start up test */
    startup_test();

    /*initialize timer for periodic data sensing*/
    TIMER_Init();
    //I2C_Init();
    /*LED task creation*/
    xTaskCreate(LEDTask, (const portCHAR *)"LED",  configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    /*Logger task creation*/
    xTaskCreate(LoggerTask, (const portCHAR *)"Serial",  configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    /*alcohol task creation*/
    xTaskCreate(alcohol_sensor, (const portCHAR *)"alcohol_task",  configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    /*ultrasonic task creation*/
    xTaskCreate(ultrasonic_sensor, (const portCHAR *)"Temperature",  configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    //xTaskCreate(TemperatureTask, (const portCHAR *)"Temperaturee",  configMINIMAL_STACK_SIZE, NULL, 1, NULL);

    vTaskStartScheduler();
    return 0;
}

void TIMER_Init()
{
       /*Run come every 100 ms*/
       TimerHandle_t myTimer = NULL;
       myTimer = xTimerCreate(
               "Timer1",
               pdMS_TO_TICKS(100),
               pdTRUE,
               (void *) pvTimerGetTimerID(myTimer),
               timerTask
             );
      xTimerStart(myTimer, 0);
}


/*  ASSERT() Error function
 *
 *  failed ASSERTS() from driverlib/debug.h are executed in this function
 */
void __error__(char *pcFilename, uint32_t ui32Line)
{
    // Place a breakpoint here to capture errors until logging routine is finished
    while (1)
    {
    }
}


