/*
 * prj2_gpio.h
 *
 *  Created on: Apr 21, 2019
 *      Author: harsi
 */

#ifndef INCLUDE_PRJ2_GPIO_H_
#define INCLUDE_PRJ2_GPIO_H_

#include <include/FreeRTOSConfig.h>
#include <include/harry_i2c.h>
#include <include/main.h>
#include <include/threads.h>
#include <include/prj2_gpio.h>

/*standard libraries*/
#include <stdint.h>
#include <stdbool.h>
#include "drivers/pinout.h"
#include "utils/uartstdio.h"


// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "inc/hw_ints.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/gpio.h"


/* -------------------------------*/
/**
 * @Synopsis enable and intialize the gpio ports and pins
 */
/* ---------------------------------*/
void GPIO_Init();


#endif /* INCLUDE_PRJ2_GPIO_H_ */
