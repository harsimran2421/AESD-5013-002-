/*
 * temperature.h
 *
 *  Created on: Apr 10, 2019
 *      Author: harsi
 */

#ifndef INCLUDE_TEMPERATURE_H_
#define INCLUDE_TEMPERATURE_H_
#include <include/harry_i2c.h>
#include <include/main.h>
#include <include/threads.h>
#include <include/prj2_gpio.h>
#include <include/harry_i2c.h>

#define MAX_TIME 7500

typedef enum{FAHRENHEIT, KELVIN, CELCIUS}conversion_enum;
/* -------------------------------*/
/**
 * @Synopsis  Function to read sensor value using GPIOs
 *
 * @Param distance_value  variable used to return the sensor value to the calling function
 *
 * @Returns Exit status based on success
 */
/* ---------------------------------*/
status_enum ultrasonic_sensor_read(float *distance_value);

/* -------------------------------*/
/**
 * @Synopsis  Function to read temperature value from sensor using I2C
 *
 * @Param request
 * @Param temp_value
 *
 * @Returns   
 */
/* ---------------------------------*/
status_enum temp_main(conversion_enum request, double *temp_value);

#endif /* INCLUDE_TEMPERATURE_H_ */
