/*
 * threads.h
 *
 *  Created on: Apr 9, 2019
 *      Author: harsi
 */

/* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.
* File Name : thread.h
* Creation Date : 21-03-2019
* Last Modified : Wed 29 April 2019 00:20:56 PM MDT
* Created By : Harsimransingh and Yasir Shah
* Description: header file to contatainging function declaration for threads created
*
* Functions:
*           queue_create();
            LEDTask();
            LoggerTask();
            TemperatureTask();
            ultrasonic_sensor();
            alcohol_sensor();
            timerTask();
            startup_test();
* References:
*
_._._._._._._._._._._._._._._._._._._._._.*/

#ifndef INCLUDE_THREADS_H_
#define INCLUDE_THREADS_H_

#include <include/main.h>
#include "FreeRTOS.h"
#include "queue.h"
#include"semphr.h"
#include<stdint.h>
#include "FreeRTOS.h"
#include "task.h"
#include "driverlib/timer.h"
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/interrupt.h"
#include "timers.h"
#include <include/prj2_gpio.h>
#include <include/prj2_alcohol.h>
#include <include/prj2_uart.h>

typedef struct{
    uint8_t thread_id;
    float sensor_value;
}msg_struct;


/*Semaphores used for signalling*/
xSemaphoreHandle log_m;
SemaphoreHandle_t led_signal;
SemaphoreHandle_t temp_signal;
SemaphoreHandle_t temperature_signal;
SemaphoreHandle_t alcohol_signal;
TaskHandle_t a_task ;

/*common queue used for data passing*/
QueueHandle_t queue_logger;

/*Flag used to see if uart connection is active or not*/
uint8_t uart_connect_flag;


/* -------------------------------*/
/**
 * @Synopsis  creates a queue of size 10 to pass data between different tasks
 *
 * @Returns   Exit status based on success or failure
 */
/* ---------------------------------*/
int queue_create();

/* -------------------------------*/
/**
 * @Synopsis  Led task handling the output devices
 *
 * @Param pvParameters
 */
/* ---------------------------------*/
void LEDTask(void *pvParameters);

/* -------------------------------*/
/**
 * @Synopsis Task to log data on UART terminal
 *
 * @Param pvParameters
 */
/* ---------------------------------*/
void LoggerTask(void *pvParameters);

/* -------------------------------*/
/**
 * @Synopsis task to measure value from TMP102 sensor
 *
 * @Param pvParameters
 */
/* ---------------------------------*/
void TemperatureTask(void *pvParameters);

/* -------------------------------*/
/**
 * @Synopsis task to collect data values from ultrasonic sensor
 *
 * @Param pvParameters
 */
/* ---------------------------------*/
void ultrasonic_sensor(void *pvParameters);

/* -------------------------------*/
/**
 * @Synopsis task to collect data values from alcohol sensor
 *
 * @Param pvParameters
 */
/* ---------------------------------*/
void alcohol_sensor(void *pvParameters);

/* -------------------------------*/
/**
 * @Synopsis Timer task to signal other task to periodically collect data
 *
 * @Param mytimer
 */
/* ---------------------------------*/
void timerTask(TimerHandle_t mytimer);

/* -------------------------------*/
/**
 * @Synopsis function to execute start tests before creating tests
 */
/* ---------------------------------*/
void startup_test();
#endif /* INCLUDE_THREADS_H_ */
