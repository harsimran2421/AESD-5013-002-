/*
 * prj2_uart.c
 *
 *  Created on: Apr 21, 2019
 *      Author: harsi
 */

#include <include/prj2_uart.h>

void configure_UART(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);
    UARTStdioConfig(0, 57600, 16000000);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART7);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    IntMasterEnable();
    GPIOPinConfigure(GPIO_PC4_U7RX);
    GPIOPinConfigure(GPIO_PC5_U7TX);
    GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5);
    UARTConfigSetExpClk(UART7_BASE, 120000000, 115200,
                        (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
                        UART_CONFIG_PAR_NONE));
    IntEnable(INT_UART7);
    UARTIntRegister(UART7_BASE, UARTIntHandler);
    ROM_UARTIntEnable(UART7_BASE, UART_INT_RX | UART_INT_RT);
}

void UARTIntHandler(void)
{
    uint32_t ui32Status;
    char uart_val;
    ui32Status = ROM_UARTIntStatus(UART7_BASE, true);
    ROM_UARTIntClear(UART7_BASE, ui32Status);
    uart_val = UARTCharGet(UART7_BASE);
    control_flag = (uint8_t)uart_val;
    uart_flag = 1;
    uart_connect_flag = 1;
    //UARTCharPut(UART0_BASE, uart_val);
}

void UARTSend(const uint8_t *pui8Buffer, uint32_t ui32Count)
{
    while(ui32Count--)
    {
        //UARTprintf("\r\n%d",ui32Count);
        UARTprintf("");
        int i = 0;
        for(i = 0; i< 1000; i++);
        ROM_UARTCharPutNonBlocking(UART7_BASE, *pui8Buffer++);
    }
}
