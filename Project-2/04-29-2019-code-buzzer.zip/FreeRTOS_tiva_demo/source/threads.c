/*
 * threads.c
 *
 *  Created on: Apr 9, 2019
 *      Author: harsi
 *      reference: https://github.com/akobyl/TM4C129_FreeRTOS_Demo
 *      reference
 */
#include <include/FreeRTOSConfig.h>
#include <include/main.h>
#include <include/temperature.h>
#include <include/threads.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "drivers/pinout.h"
#include "utils/uartstdio.h"


// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/timer.h"
#include "driverlib/interrupt.h"

// FreeRTOS includes
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

//QueueHandle_t queue_logger;
int queue_create(){
    queue_logger = xQueueCreate( 10, sizeof(msg_struct) );
    if( queue_logger == NULL )
       {
           return 0;
       }
    return 1;
}


// Flash the LEDs on the launchpad
void LEDTask(void *pvParameters)
{
    //vTaskDelay(1000);
    while(1)
    {
        if(control_flag == 1)
        {
            LEDWrite(0x01, 0x01);
        }

        else if(control_flag == 6)
        {
            LEDWrite(0x02, 0x02);
            GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_1, GPIO_PIN_1);
        }
        else if(control_flag == 5)
        {
            LEDWrite(0x02, 0x00);
            GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_1, ~GPIO_PIN_1);
        }
        else if(control_flag == 0)
        {
            LEDWrite(0x01, 0x00);
        }
    }
}


// Write text over the Stellaris debug interface UART port
void LoggerTask(void *pvParameters)
{
    msg_struct msg;
    uart_flag = 1;
    char temp[20];
    memset(temp,'\0',20);
    while(1)
    {
                if (xQueueReceive(queue_logger, &(msg),(TickType_t ) 1) == pdTRUE)
                {
                    uint8_t *send_ptr = (uint8_t *)&msg;
                    UARTSend(send_ptr,sizeof(msg));
                    if(msg.thread_id == 3)
                    {

                        UARTprintf("\n\n\rultrasonic task\nAuthor: Harry\nsensor value = %u \n\r ",(uint32_t) msg.sensor_value);
                    }
                    else if(msg.thread_id == 2)
                    {

                        sprintf(temp,"%f",msg.sensor_value);
                        UARTprintf("\n\n\ralcohol task\nAuthor: Harry\nsensor value = %s \n\r ", temp);
                    }
                    else if(msg.thread_id == 4)
                    {
                        UARTprintf("\n\n\ralcohol task\nAuthor: Harry\nAlcohol sensor Disconnected \n\r ");
                    }
                    if(msg.thread_id == 5)
                    {

                        UARTprintf("\n\n\rultrasonic task\nAuthor: Harry\nUltrasonic sensor Disconnected\n\r ");
                    }
                }
    }
}

void ultrasonic_sensor(void *pvParameters)
{
    static uint8_t ultrasonic_disconnect_flag;
    msg_struct msg;
    float sensor_value;
    while(1)
    {
        if (xSemaphoreTake(temp_signal,portMAX_DELAY) == pdTRUE)
        {
            ultrasonic_sensor_read(&sensor_value);
            msg.sensor_value = sensor_value;
            msg.thread_id = 3;
            if(sensor_value < 0)
            {
               if(ultrasonic_disconnect_flag == 0)
                {
                    ultrasonic_disconnect_flag = 1;
                    control_flag = 1;
                    msg.thread_id = 5;
                    if (xSemaphoreTake( log_m, ( TickType_t )20 ) == pdTRUE)
                        ;
                    {
                        xQueueSend(queue_logger, (void * ) &msg, (TickType_t )1);
                        xSemaphoreGive(log_m);
                    }
                }
            }
            else
            {
                ultrasonic_disconnect_flag = 0;
                if(uart_connect_flag == 0)
                {
                    LEDWrite(0x04, 0x04);
                    if(msg.sensor_value < 10)
                        control_flag = 1;
                    else
                        control_flag = 0;
                }
                else
                    LEDWrite(0x04, 0x00);
                if (xSemaphoreTake( log_m, ( TickType_t )20 ) == pdTRUE)
                    ;
                {
                    xQueueSend(queue_logger, (void * ) &msg, (TickType_t )1);
                    xSemaphoreGive(log_m);
                }
            }
       }
    }
}

void alcohol_sensor(void *pvParameters)
{
    static uint8_t alcohol_disconnect_flag;
    float clean_threshold = alcohol_sensor_config();
    char string_content[10];
    sprintf(string_content, "%f", clean_threshold);
    msg_struct msg;
    uint32_t initial_data[1];
    float alcohol_ratio = 0.0;
    while(1)
    {
        if (xSemaphoreTake(alcohol_signal,portMAX_DELAY) == pdTRUE)
        {
            ADCProcessorTrigger(ADC0_BASE, 3);

            while (!ADCIntStatus(ADC0_BASE, 3, false))
                ;

            ADCIntClear(ADC0_BASE, 3);


            ADCSequenceDataGet(ADC0_BASE, 3, initial_data);

            alcohol_ratio = (3.3/4096)*initial_data[0]*10;

            msg.sensor_value = alcohol_ratio;
            msg.thread_id = 2;
            if((int)msg.sensor_value <=0)
            {
                if(alcohol_disconnect_flag == 0)
                {
                    alcohol_disconnect_flag = 1;
                    control_flag = 5;
                    msg.thread_id = 4;
                    if (xSemaphoreTake( log_m, ( TickType_t )20 ) == pdTRUE)
                        ;
                    {
                        xQueueSend(queue_logger, (void * ) &msg, (TickType_t )1);
                        xSemaphoreGive(log_m);
                    }
                }
            }
            else
            {
                if(uart_connect_flag == 0)
                {
                    LEDWrite(0x04, 0x04);
                    if(msg.sensor_value > 10)
                        control_flag = 6;
                    else
                        control_flag = 5;
                }
                else
                    LEDWrite(0x04, 0x00);
                alcohol_disconnect_flag = 0;
                if (xSemaphoreTake( log_m, ( TickType_t )20 ) == pdTRUE)
                    ;
                {
                    xQueueSend(queue_logger, (void * ) &msg, (TickType_t )1);
                    xSemaphoreGive(log_m);
                }
            }
       }
    }
}

void timerTask(TimerHandle_t mytimer)
{
    static int run_count;
    static int switch_flag;
    run_count++;
    if(run_count%10 == 0)
    {
        switch_flag = switch_flag ^ 1;
        if(switch_flag == 1)
        {
            uart_connect_flag = 0;
            xSemaphoreGive( temp_signal);
        }
        else
        {
            xSemaphoreGive( alcohol_signal);
        }
    }
}

